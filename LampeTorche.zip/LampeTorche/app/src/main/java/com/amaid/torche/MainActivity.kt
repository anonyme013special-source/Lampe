package com.amaid.torche

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var cm: CameraManager
    private var camId: String? = null
    private val h = Handler(Looper.getMainLooper())

    private var on = false
    private var lit = false
    private var mode = "fixe"
    private var rate = 5

    private lateinit var btn: Button
    private lateinit var status: TextView
    private lateinit var seekBox: LinearLayout
    private val modeButtons = mutableMapOf<String, Button>()

    private val jaune = Color.parseColor("#FFD23F")
    private val gris = Color.parseColor("#1F2228")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        camId = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        buildUi()
        if (camId == null) status.text = "Aucun flash trouvé sur cet appareil."
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#14161A"))
            setPadding(dp(24), dp(56), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Lampe torche"
            setTextColor(Color.WHITE); textSize = 22f; setTypeface(null, Typeface.BOLD)
        })

        btn = Button(this).apply {
            text = "Allumer"; textSize = 20f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.parseColor("#8B8F98"))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(gris) }
            setOnClickListener { setOn(!on) }
        }
        root.addView(btn, LinearLayout.LayoutParams(dp(240), dp(240)).apply { topMargin = dp(40); bottomMargin = dp(40) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("fixe" to "Fixe", "strobo" to "Stroboscope", "sos" to "SOS").forEach { (key, label) ->
            val b = Button(this).apply {
                text = label; isAllCaps = false; setTextColor(Color.WHITE)
                setOnClickListener { setMode(key) }
            }
            modeButtons[key] = b
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6); marginStart = dp(6) })
        }
        root.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        seekBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = LinearLayout.GONE }
        val seekLabel = TextView(this).apply { text = "Vitesse : 5 flashs/s"; setTextColor(Color.parseColor("#8B8F98")) }
        val seek = SeekBar(this).apply {
            max = 9; progress = 4
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    rate = p + 1; seekLabel.text = "Vitesse : $rate flashs/s"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        seekBox.addView(seekLabel); seekBox.addView(seek)
        root.addView(seekBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })

        status = TextView(this).apply { setTextColor(Color.parseColor("#8B8F98")); gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })

        setContentView(root)
        refreshModes()
    }

    private fun refreshModes() {
        modeButtons.forEach { (k, b) -> b.background = round(if (k == mode) jaune else gris, 12); b.setTextColor(if (k == mode) Color.BLACK else Color.WHITE) }
        seekBox.visibility = if (mode == "strobo") LinearLayout.VISIBLE else LinearLayout.GONE
    }

    private fun setMode(m: String) {
        mode = m; refreshModes()
        if (on) start()
    }

    private fun torch(v: Boolean) {
        val id = camId ?: return
        try { cm.setTorchMode(id, v); lit = v } catch (e: Exception) { status.text = "Impossible de contrôler le flash." }
    }

    private fun setOn(v: Boolean) {
        if (camId == null) return
        on = v
        h.removeCallbacksAndMessages(null)
        if (v) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            btn.text = "Éteindre"; btn.setTextColor(Color.BLACK)
            btn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(jaune) }
            status.text = "Lampe allumée."
            start()
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            torch(false)
            btn.text = "Allumer"; btn.setTextColor(Color.parseColor("#8B8F98"))
            btn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(gris) }
            status.text = "Lampe éteinte."
        }
    }

    private fun start() {
        h.removeCallbacksAndMessages(null)
        when (mode) {
            "fixe" -> torch(true)
            "strobo" -> h.post(object : Runnable {
                override fun run() {
                    if (!on) return
                    torch(!lit)
                    h.postDelayed(this, (500 / rate).toLong())
                }
            })
            "sos" -> {
                val steps = mutableListOf<Pair<Boolean, Long>>()
                listOf(1, 1, 1, 3, 3, 3, 1, 1, 1).forEachIndexed { i, u ->
                    steps.add(true to u * 200L)
                    steps.add(false to if (i == 2 || i == 5 || i == 8) 800L else 200L)
                }
                var idx = 0
                h.post(object : Runnable {
                    override fun run() {
                        if (!on) return
                        val (state, ms) = steps[idx]
                        torch(state)
                        idx = (idx + 1) % steps.size
                        h.postDelayed(this, ms)
                    }
                })
            }
        }
    }

    override fun onPause() {
        super.onPause()
        if (on) setOn(false)
    }
}
